import pickle
from pathlib import Path

import pandas as pd
import streamlit as st

APP_DIR = Path(__file__).resolve().parent
MODEL_PATH = APP_DIR / "model.pkl"

st.set_page_config(
    page_title="Model Prediction App",
    page_icon="🤖",
    layout="centered",
)

@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "model.pkl was not found. Upload model.pkl to the same GitHub repository folder as app.py."
        )
    with MODEL_PATH.open("rb") as model_file:
        return pickle.load(model_file)

st.title("🤖 Machine Learning Prediction App")
st.write(
    "This app loads your trained Random Forest classifier and predicts a category "
    "from the two input features it was trained on."
)

st.info(
    "Important: the training script generates a synthetic demonstration dataset. "
    "The model predicts Category A, Category B, or Category C; it is not a pizza "
    "type or pizza-quality classifier."
)

try:
    model = load_model()
except Exception as exc:
    st.error(f"Could not load the model: {exc}")
    st.stop()

st.subheader("Enter feature values")
col1, col2 = st.columns(2)

with col1:
    feature1 = st.number_input(
        "Feature1",
        min_value=-100.0,
        max_value=200.0,
        value=50.0,
        step=1.0,
        help="The first numeric input used during training.",
    )

with col2:
    feature2 = st.number_input(
        "Feature2",
        min_value=-100.0,
        max_value=100.0,
        value=20.0,
        step=1.0,
        help="The second numeric input used during training.",
    )

if st.button("Predict category", type="primary", use_container_width=True):
    input_data = pd.DataFrame(
        [[feature1, feature2]],
        columns=["Feature1", "Feature2"],
    )
    prediction = model.predict(input_data)[0]

    st.success(f"Predicted category: **{prediction}**")

    if hasattr(model, "predict_proba"):
        probabilities = model.predict_proba(input_data)[0]
        probability_df = pd.DataFrame(
            {"Category": model.classes_, "Probability": probabilities}
        ).sort_values("Probability", ascending=False)
        probability_df["Probability"] = probability_df["Probability"].map(
            lambda value: f"{value:.1%}"
        )
        st.subheader("Model class probabilities")
        st.dataframe(probability_df, hide_index=True, use_container_width=True)

with st.expander("About this model"):
    st.write(f"Model type: `{type(model).__name__}`")
    st.write("Input features: `Feature1`, `Feature2`")
    st.write("Output classes: `Category A`, `Category B`, `Category C`")
    st.caption(
        "The displayed probabilities are model estimates, not guarantees. "
        "Use only with data appropriate to the model's training."
    )

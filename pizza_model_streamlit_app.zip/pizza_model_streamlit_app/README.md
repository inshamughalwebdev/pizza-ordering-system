# Machine Learning Prediction App

A simple Streamlit web app that loads the trained Random Forest model from `model.pkl` and predicts one of its three classes.

> **Important:** The supplied training script creates a synthetic demonstration dataset with `Feature1`, `Feature2`, and labels `Category A`, `Category B`, and `Category C`. Despite the original filename mentioning pizza, this model is **not trained to classify pizzas**.

## Files to upload to GitHub

Keep these files together in the repository root:

- `app.py` — Streamlit application.
- `model.pkl` — the trained model file.
- `requirements.txt` — Python packages needed by the app.
- `README.md` — project and deployment instructions.
- `.gitignore` — excludes common local and temporary files.

The original `.py` training script and `.ipynb` notebook are useful for documenting or retraining the model, but they are not required to run the deployed app.

## Run locally

Use Python 3.10 or 3.11 for a straightforward deployment environment.

```bash
python -m venv .venv
```

Activate the environment:

- Windows: `.venv\\Scripts\\activate`
- macOS/Linux: `source .venv/bin/activate`

Then install dependencies and run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy using Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload `app.py`, `model.pkl`, `requirements.txt`, `README.md`, and `.gitignore` to the repository root.
3. Open [Streamlit Community Cloud](https://share.streamlit.io/) and sign in with GitHub.
4. Choose **Create app**, select your repository and branch, and set the main file path to `app.py`.
5. Deploy the app.

Keep `model.pkl` in the same directory as `app.py`. The app expects that exact filename.

## Model compatibility and security

`requirements.txt` pins scikit-learn to `1.6.1`, the version reported by the supplied pickle file's compatibility warning. Pickle files can execute code when loaded, so deploy only a model file you trust. A pickle created with a different Python/scikit-learn environment may need to be regenerated.

## Model limitations

The current training script creates random synthetic data. Predictions demonstrate how to connect a trained model to a web UI; they should not be interpreted as meaningful real-world classifications until the model is trained and validated on an appropriate real dataset.
